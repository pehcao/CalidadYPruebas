#include <string>
#include <fstream>

extern void CvT_StartRecording____();

int main()
{

  CvT_StartRecording____();

  string x("crap");
  string y("junk");

  string z = x + y;

  cout << z << endl;

}
