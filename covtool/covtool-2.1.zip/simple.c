int x;
int y;
extern void CvT_StartRecording____();

int main()
{
  CvT_StartRecording____();
  x = y;
  y += x-y;
}
