#include <stdio.h>

int main(int argc, char **argv)
{
   if(argc == 2)
   {
     printf("one parm\n");
   }
   else
   if(argc == 3)
   {
     printf("two parms\n");
   }
   else
   if(argc == 4)
   {
     printf("three parms\n");
   }


}



