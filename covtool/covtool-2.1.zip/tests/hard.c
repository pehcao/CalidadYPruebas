#include <string>
#include <fstream>
#include <iostream>

using namespace std;

int main()
{

  string x("crap");
  string y("junk");

  string z = x + y;

  cout << z << endl;

}
