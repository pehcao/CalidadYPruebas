int x;
int y;

int main()
{
  x = y;
  y += x-y;
}
