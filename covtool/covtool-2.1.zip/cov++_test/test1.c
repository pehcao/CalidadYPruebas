#if defined(define1) && defined(define2)

#include <read_database.h>

int main()
{
  cout << "test1 is running";
  cout << I_STRING << endl;


}

#endif
